public interface ConversaoFinanceira {

    public void converterDolarParaReal(double valorDolar);
}
