public interface ConversorTemperatura {

    public void celsiusParaFahrenheit(double  tempCelsius);
    public void  fahrenheitParaCelsius(double  tempFahrenheit);
}
