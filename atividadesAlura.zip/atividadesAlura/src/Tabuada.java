public interface Tabuada {

    public void mostrarTabuada(int numero);
}
